package es.jfp;

import es.jfp.elements.AppFrame;

public class Main {
	
	public static void main(String[] args) {
		
		AppFrame chatMarco = new AppFrame();
		chatMarco.setVisible(true);
	}
	

}
