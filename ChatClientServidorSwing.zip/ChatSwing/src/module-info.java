/**
 * 
 */
/**
 * 
 */
module ChatSwing {
	requires java.desktop;
}