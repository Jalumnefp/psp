/**
 * 
 */
/**
 * 
 */
module ServerChat {
	requires java.desktop;
}